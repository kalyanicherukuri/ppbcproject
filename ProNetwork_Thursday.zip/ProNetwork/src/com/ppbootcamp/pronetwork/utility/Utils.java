package com.ppbootcamp.pronetwork.utility;

import java.util.ArrayList;

import com.ppbootcamp.pronetwork.entity.EducationBean;
import com.ppbootcamp.pronetwork.entity.EmploymentBean;

public class Utils {

	public static ArrayList<EmploymentBean> createEmploymentBean(String employmentDetails) {
		ArrayList<EmploymentBean> employmentBeanList = new ArrayList<EmploymentBean>();
		EmploymentBean employmentBean = new EmploymentBean();
		//String employment;
		String[] employmentDetailsList = employmentDetails.split(",",0);
		String empdetails[];
		
		//String[] elements = { "a","a","a","a" };
		
		for (String empl: employmentDetailsList) {  
			    employmentBean = new EmploymentBean();
			    empdetails = empl.split(":", 0);
			    employmentBean.setCompany(empdetails[0]);
			    employmentBean.setSyear(empdetails[1]);
			    employmentBean.setEyear(empdetails[2]);
			    employmentBeanList.add(employmentBean);
	    }
		return employmentBeanList;
	}
	
	public static ArrayList<EducationBean> createEducationBean(String educationDetails) {
		ArrayList<EducationBean> educationBeanList = new ArrayList<EducationBean>();
		EducationBean educationBean = new EducationBean();
		
		String[] educationDetailsList = educationDetails.split(",",0);
		String edudetails[];
		
		//String[] elements = { "a","a","a","a" };
		
		for (String empl: educationDetailsList) {  
			educationBean = new EducationBean();
			    edudetails = empl.split(":", 0);
			    educationBean.setInstitution(edudetails[0]);
			    educationBean.setDegree(edudetails[1]);
			    educationBean.setYear(Integer.parseInt(edudetails[2]));
			    educationBeanList.add(educationBean);
	    }
		return educationBeanList;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
