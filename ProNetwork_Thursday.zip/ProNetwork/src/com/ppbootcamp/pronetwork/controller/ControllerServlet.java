package com.ppbootcamp.pronetwork.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ppbootcamp.pronetwork.dataaccess.ExistingPersonDataAccess;
import com.ppbootcamp.pronetwork.dataaccess.NewPersonDataAccess;
import com.ppbootcamp.pronetwork.entity.LoginBean;
import com.ppbootcamp.pronetwork.entity.Person;
import com.ppbootcamp.pronetwork.utility.Utils;

public class ControllerServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String action = request.getParameter("action_details");
		
		if(action.equalsIgnoreCase("newuseradd")) {
			
			try  {
				
				String name = request.getParameter("name");
				String mailid = request.getParameter("mailid");
				String password = request.getParameter("password");
				
				String educationDetails = request.getParameter("educationdetails");
								
				/*String year = request.getParameter("year");
				String institution = request.getParameter("institution");
				String degree = request.getParameter("degree");*/
				
				String employmentDetails = request.getParameter("employmentdetails");
				
				/*String company = request.getParameter("company");
				String syear = request.getParameter("syear");
				String eyear = request.getParameter("eyear");*/
				
				String skills = request.getParameter("skills");
				
				if (name != null && mailid != null)  {
					Person person = new Person();
					person.setName(name);
					person.setMailid(mailid);
					person.setPassword(password);
					person.setSkills(skills);
					
					if(employmentDetails!=null&&employmentDetails.length()!=0) {
						person.setEmploymentBean(Utils.createEmploymentBean(employmentDetails));
					}
					
					if(educationDetails!=null&&educationDetails.length()!=0) {
						person.setEducationBean(Utils.createEducationBean(educationDetails));
					}
  				    NewPersonDataAccess newPersonDAO = new NewPersonDataAccess();
					newPersonDAO.insertPersonData(person);
				}
				else {
					
				}
			}
			catch (Exception ex) {
				
			}
			
		}
		
		if(action.equalsIgnoreCase("loginauth")) {
			
			String mailid=request.getParameter("mailid");
			String password=request.getParameter("password");
			
			LoginBean loginBean=new LoginBean();
			
			loginBean.setMailid(mailid);
			loginBean.setPassword(password);
			
			request.setAttribute("bean",loginBean);
			ExistingPersonDataAccess existingPersonDetails = new ExistingPersonDataAccess();
			Person person = existingPersonDetails.validateandRetrieve(loginBean);
	
			if(person!=null) {
				RequestDispatcher rd=request.getRequestDispatcher("login-success.jsp");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("login-error.jsp");
				rd.forward(request, response);
			}
		
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
}
	

