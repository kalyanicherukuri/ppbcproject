package com.ppbootcamp.pronetwork.dataaccess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ppbootcamp.pronetwork.dbconnectivity.ProNetworkDataSource;
import com.ppbootcamp.pronetwork.entity.ConnectionBean;

public class ConnectionsDataAccess {
	public ArrayList<ConnectionBean> getRecommendations(int id) {
		ArrayList<ConnectionBean> connectionBeanList;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		
		try {
			conn = ProNetworkDataSource.getPNDataSource().getConnection();
			
			PreparedStatement preStatement=conn.prepareStatement("select id, name from person where id in (select s.id from employment s JOIN employment t on s.company = t.company where t.id = ? and s.id!=t.id UNION select s.id from education s JOIN education t on s.institution = t.institution where t.id = ? and s.id!=t.id)");
			preStatement.setInt(1, id);
			preStatement.setInt(2, id);
			rset = preStatement.executeQuery();
			
			
			select id, name from person where id in (
					select s.id from employment s JOIN employment t on s.company = t.company where t.id = 1 and s.id!=t.id UNION

					select s.id from education s JOIN education t on s.institution = t.institution where t.id = 1 and s.id!=t.id )
		
		
		return connectionBeanList;
	}
}
