package com.ppbootcamp.pronetwork.dataaccess;

import java.sql.*;
import java.util.ArrayList;

import com.ppbootcamp.pronetwork.dbconnectivity.ProNetworkDataSource;
import com.ppbootcamp.pronetwork.entity.EmploymentBean;
import com.ppbootcamp.pronetwork.entity.EducationBean;
import com.ppbootcamp.pronetwork.entity.Person;

public class NewPersonDataAccess {

	public void insertPersonData( Person person )throws Exception {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		int id;
		try {
			conn = ProNetworkDataSource.getPNDataSource().getConnection();
			stmt = conn.createStatement();
			rset = stmt.executeQuery("select max(id) from person");
			if(rset.next()) {
				id = rset.getInt(1);
				id = id+1;
			}
			else {
				id = 1;
			}
			
			PreparedStatement preStatement=conn.prepareStatement("insert into person(id,mailid,name,password,skills) values(?,?,?,?,?)");
			preStatement.setInt(1, id);
			preStatement.setString(2, person.getMailid());
			preStatement.setString(3, person.getName());
			preStatement.setString(4,person.getPassword());
			preStatement.setString(5,person.getSkills());
			preStatement.executeQuery();
			
			ArrayList<EmploymentBean> employmentBeanList = person.getEmploymentBean();
			
			if(employmentBeanList!=null && employmentBeanList.size()>0) {
				for (EmploymentBean employmentBean: employmentBeanList) {
					preStatement=conn.prepareStatement("insert into EMPLOYMENT(ID, START_YEAR, END_YEAR, COMPANY) values(?,?,?,?)");
					preStatement.setInt(1, id);
					preStatement.setString(2, employmentBean.getSyear());
					preStatement.setString(3, employmentBean.getEyear());
					preStatement.setString(4,employmentBean.getCompany());
					preStatement.executeQuery();					
				}
			}
			
			ArrayList<EducationBean> educationBeanList = person.getEducationBean();
			
			if(educationBeanList!=null && educationBeanList.size()>0) {
				for (EducationBean educationBean: educationBeanList) {
			
			preStatement=conn.prepareStatement("insert into EDUCATION(ID, YEAR, DEGREE_LEVEL, INSTITUTION) values(?,?,?,?)");
			preStatement.setInt(1, id);
			preStatement.setInt(2, educationBean.getYear());
			preStatement.setString(3, educationBean.getDegree());
			preStatement.setString(4,educationBean.getInstitution());
			preStatement.executeQuery();
				}
			}
			conn.commit();
		}
		catch (Exception ex) {
			System.out.println("Exception..."+ex.getStackTrace());
			ex.printStackTrace();
			throw ex;
		}
		
	}

}
