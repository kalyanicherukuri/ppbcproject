package com.ppbootcamp.pronetwork.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ppbootcamp.pronetwork.dataaccess.ConnectionsDataAccess;
import com.ppbootcamp.pronetwork.dataaccess.ExistingPersonDataAccess;
import com.ppbootcamp.pronetwork.dataaccess.NewPersonDataAccess;
import com.ppbootcamp.pronetwork.entity.ConnectionBean;
import com.ppbootcamp.pronetwork.entity.LoginBean;
import com.ppbootcamp.pronetwork.entity.PersonBean;
import com.ppbootcamp.pronetwork.utility.Utils;

public class ControllerServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String action = request.getParameter("action_details");
		
		if(action.equalsIgnoreCase("newuseradd")) {
			
			try  {
				
				String name = request.getParameter("name");
				String mailid = request.getParameter("mailid");
				String password = request.getParameter("password");
				
				String educationDetails = request.getParameter("educationdetails");
								
				/*String year = request.getParameter("year");
				String institution = request.getParameter("institution");
				String degree = request.getParameter("degree");*/
				
				String employmentDetails = request.getParameter("employmentdetails");
				
				/*String company = request.getParameter("company");
				String syear = request.getParameter("syear");
				String eyear = request.getParameter("eyear");*/
				
				String skills = request.getParameter("skills");
				
				if (name != null && mailid != null)  {
					PersonBean personBean = new PersonBean();
					personBean.setName(name);
					personBean.setMailid(mailid);
					personBean.setPassword(password);
					personBean.setSkills(skills);
					
					if(employmentDetails!=null&&employmentDetails.length()!=0) {
						personBean.setEmploymentBean(Utils.createEmploymentBean(employmentDetails));
					}
					
					if(educationDetails!=null&&educationDetails.length()!=0) {
						personBean.setEducationBean(Utils.createEducationBean(educationDetails));
					}
  				    NewPersonDataAccess newPersonDAO = new NewPersonDataAccess();
					newPersonDAO.insertPersonData(personBean);
				}
				else {
					
				}
			}
			catch (Exception ex) {
				displayErrorOnWeb(ex,out);
			}
			
		}
		
		if(action.equalsIgnoreCase("loginauth")) {
			try {
				String mailid=request.getParameter("mailid");
				String password=request.getParameter("password");
				
				LoginBean loginBean=new LoginBean();
				
				loginBean.setMailid(mailid);
				loginBean.setPassword(password);
				
				//request.setAttribute("bean",loginBean);
				ExistingPersonDataAccess existingPersonDetails = new ExistingPersonDataAccess();
				PersonBean personBean = existingPersonDetails.validateandRetrieve(loginBean);
		
				if(personBean!=null) {
					request.setAttribute("bean",personBean);
					RequestDispatcher rd=request.getRequestDispatcher("PersonInfo.jsp");
					rd.forward(request, response);
				}
				else {
					RequestDispatcher rd=request.getRequestDispatcher("login-error.jsp");
					rd.forward(request, response);
				}
			}
			catch (Exception ex) {
				displayErrorOnWeb(ex,out);
			}
			
		}
		if(action.equalsIgnoreCase("existing_conn")) {
			try	{
				
				int id = Integer.parseInt(request.getParameter("id"));
				ConnectionsDataAccess connDataDetails = new ConnectionsDataAccess();
				ArrayList<ConnectionBean> connBeanList = connDataDetails.getExisting(id);
				
			}
			catch (Exception ex) {
				displayErrorOnWeb(ex,out);
			}
			
		}
		if(action.equalsIgnoreCase("recommend_conn")) {
			int id = Integer.parseInt(request.getParameter("id"));
			ConnectionsDataAccess connDataDetails = new ConnectionsDataAccess();
			try {
				ArrayList<ConnectionBean> connBeanList = connDataDetails.getRecommendations(id);
				
			}
			catch (Exception ex) {
				displayErrorOnWeb(ex,out);
			}
			
		}
		if(action.equalsIgnoreCase("invitation_conn")) {
			int id = Integer.parseInt(request.getParameter("id"));
			ConnectionsDataAccess connDataDetails = new ConnectionsDataAccess();
			try {
				ArrayList<ConnectionBean> connBeanList = connDataDetails.getInvitations(id);
				
			}
			catch (Exception ex) {
				displayErrorOnWeb(ex,out);
			}
			
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
	
	public void displayErrorOnWeb(Throwable t,PrintWriter out) {
		out.println("<br/><br/>An error occurred while processing your request.Please try again:</br>");
		out.println("<br/><br/>Stack Trace:</br>");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		t.printStackTrace(pw);
		String stackTrace = sw.toString();
		out.println(stackTrace.replace(System.getProperty("line.separator"), "<br/>\n"));
	}
}
	

