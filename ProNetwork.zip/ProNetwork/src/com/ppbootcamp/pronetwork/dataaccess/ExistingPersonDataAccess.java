package com.ppbootcamp.pronetwork.dataaccess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ppbootcamp.pronetwork.dbconnectivity.ProNetworkDataSource;
import com.ppbootcamp.pronetwork.entity.LoginBean;
import com.ppbootcamp.pronetwork.entity.Person;

public class ExistingPersonDataAccess {
	
	public Person validateandRetrieve (LoginBean loginBean) {
		Person person = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		int id;
		try {
			conn = ProNetworkDataSource.getPNDataSource().getConnection();
			pstmt = conn.prepareStatement("select id from person where mailid=? and password=?");
			pstmt.setString(1, loginBean.getMailid());
			pstmt.setString(2, loginBean.getPassword());
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				id = Integer.parseInt((String)rset.getObject(1));
				person =  retrievePersonData(id);
			}
		}
		catch (Exception ex) {
			
		}
		finally {
			try {
				rset.close();
				pstmt.close();
				conn.close();
			}
			catch (SQLException ex) {
				
			}
		}
		return person;		
	}

	private Person retrievePersonData(int id) {
		Person person = new Person();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		try {
			conn = ProNetworkDataSource.getPNDataSource().getConnection();
			pstmt = conn.prepareStatement("select id,mailid,name,skills from person where id=?");
			pstmt.setInt(1, id);
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
	             person.setId(rset.getInt("id"));
	             person.setName(rset.getString("name"));
	             person.setMailid(rset.getString("mailid"));
	             person.setSkills(rset.getString("skills"));	             
			}
			
			pstmt = conn.prepareStatement("select * from employment where id=?");
			pstmt.setInt(1, id);
			rset = pstmt.executeQuery();
			while(rset.next()) {
				
			}
		}
		catch(Exception ex) {
		
		}
		finally {
				try {
					rset.close();
					pstmt.close();
					conn.close();
				}
				catch (SQLException ex) {
					
				}
		}
			return person;
	}
}
