package com.ppbootcamp.pronetwork.dataaccess;

import java.sql.*;
import com.ppbootcamp.pronetwork.dbconnectivity.ProNetworkDataSource;
import com.ppbootcamp.pronetwork.entity.Person;

public class NewPersonDataAccess {

	public void insertPersonData( Person person ) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		int id = null;
		try {
			conn = ProNetworkDataSource.getPNDataSource().getConnection();
			stmt = conn.createStatement();
			rset = stmt.executeQuery("select max(id) from person");
			if(!(rset.next()!=null)) {
				int id = Integer.parseInt(rset.getObject(1));
				id = id+1;
			}
			id = 1;
				
			PreparedStatement preStatement=conn.prepareStatement("insert into person values(id,mailid,name,password,
			
		}
		catch (Exception ex) {
			
		}
		
	}

}
