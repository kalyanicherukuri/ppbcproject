package com.ppbootcamp.pronetwork.dbconnectivity;

import java.sql.*;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.io.*;

import oracle.jdbc.OracleDriver;
import org.apache.commons.dbcp2.BasicDataSource;

public class DBConnection {
	static BasicDataSource ds ;
	
	public static DataSource getDataSource(){
		Properties props = new Properties();
		FileInputStream fis = null;
		if (ds==null)  {
		ds = new BasicDataSource();

		try {
			/*InitialContext jndiEnc = new InitialContext();
			jndiEnc = new InitialContext();
			ds = (BasicDataSource) jndiEnc.lookup("java:comp/env/jdbc/xe_bootcamp");*/
			
			ds.setDriverClassName("oracle.jdbc.OracleDriver");
			ds.setUrl("jdbc:oracle:thin:@localhost:1521/xe");
			ds.setUsername("bootcamp");
			ds.setPassword("mythri");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return ds;
	}
	
	Connection dbConnection;
	
/*	public Connection getConnection () {
		if (dbConnection!=null) {
			return dbConnection;
		}
		else {
			
			return dbConnection;
		}
	}*/

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		try {
			/*Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521/xe", "bootcamp", "mythri");*/
			conn = getDataSource().getConnection();
			stmt = conn.createStatement();
			rset = stmt.executeQuery("select * from emp"); // where empno=7839");
			while (rset.next()) {
				System.out.print(rset.getObject(1) + "\t");
				System.out.print(rset.getObject(2) + "\t");
				System.out.println(rset.wasNull());
			}
		}catch(Exception e){
			e.printStackTrace();
		} 
		finally {
/*			try {
				//stmt.close();
				//conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
	}
}
