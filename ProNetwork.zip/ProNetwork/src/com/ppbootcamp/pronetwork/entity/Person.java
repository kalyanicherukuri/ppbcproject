package com.ppbootcamp.pronetwork.entity;

public class Person {


	
	int id;
	
	// Personal Details
	String name;
	String mailid;
	String password;
	
	//Education Details
    EmploymentBean[] employmentBean; 
	
	// Professional Details
	EducationBean[] educationBean;
	
	String skills;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public EmploymentBean[] getEmploymentBean() {
		return employmentBean;
	}
	public void setEmploymentBean(EmploymentBean[] employmentBean) {
		this.employmentBean = employmentBean;
	}
	
	public EducationBean[] getEducationBean() {
		return educationBean;
	}

	public void setEducationBean(EducationBean[] educationBean) {
		this.educationBean = educationBean;
	}

	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
}
